//Used for testing log in page
var authUsers = [
  {
    "username": "shelby",
    "password": "medlock",
    "firstName": "Shelby",
    "lastName": "Medlock"
  },
  {
    "username": "tom",
    "password": "mcdonald",
    "firstName": "Tom",
    "lastName": "McDonald"
  }
]
